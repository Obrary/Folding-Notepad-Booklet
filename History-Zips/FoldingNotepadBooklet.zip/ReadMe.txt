Product: Folding Notepad Booklet, version 2, September 2014
Designer: SNIJLAB, info@snijlab.nl
Support:  support@obrary.com
Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The notepad booklet is printed on a laser cutter.  All of the product photos show it made from wood, but it could just as easily be made from acrylic.  To finish them after the laser, lightly sand and lacquer. 
