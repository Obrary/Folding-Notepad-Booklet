Product: Folding Notepad Booklet, October 2014

Designer: SNIJLAB, info@snijlab.nl

Support:  http://forums.obrary.com/category/designs/folding-notepad-booklet

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
The notepad booklet is printed on a laser cutter.  All of the product photos show it made from wood, but it could just as easily be made from acrylic.  To finish them after the laser, lightly sand and lacquer. 
